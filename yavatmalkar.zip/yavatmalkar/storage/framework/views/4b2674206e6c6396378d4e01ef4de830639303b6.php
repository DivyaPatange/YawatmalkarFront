<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title><?php echo $__env->yieldContent('title'); ?> - Index</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <?php echo $__env->make('auth.authLayout.link', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php echo $__env->yieldContent('customcss'); ?>
  
</head>

<body>
    
    <header id="header" style="background:#fff;">
        <div class="container d-flex">

        <div class="logo mr-auto">
            <h1 style="color:#232F3E;font-size:38px;font-weight:bold;">YAVATMALKAR</h1>
        </div>

        <nav class="nav-menu d-none d-lg-block">
            <ul>
            <li><a href="index.html">Home</a></li>
            <li><a href="about.html">Services</a></li>
            <li><a href="team.html">Process</a></li>
            <li><a href="team.html">Shops</a></li>
            <li><a href="contact.html">Offers</a></li>
            <li><a href="contact.html">Advertisements</a></li>
            </ul>
        </nav><!-- .nav-menu -->

        </div>
    </header>
  
    
    
  <?php echo $__env->yieldContent('content'); ?>

  <?php echo $__env->make('auth.authLayout.beautyFooter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <a href="#" class="back-to-top"><i class="icofont-simple-up"></i></a>

  <?php echo $__env->make('auth.authLayout.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php echo $__env->yieldContent('customjs'); ?>
</body>

</html><?php /**PATH C:\xampp\htdocs\yavatmalkar\resources\views/auth/authLayout/beautylayout.blade.php ENDPATH**/ ?>