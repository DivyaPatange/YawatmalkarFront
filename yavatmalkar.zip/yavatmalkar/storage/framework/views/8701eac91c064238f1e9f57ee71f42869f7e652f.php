<header id="header">
  <div class="container-fluid">
    <div class="row " style="background:#131921;padding:20px 0;color:#FFF;">
    
      <div class="col-2 logo mr-auto text-center align-self-center" style="line-height:0px;">
        
        <!-- Uncomment below if you prefer to use an image logo -->
        <a href="/">
          <h1>YAVATMALKAR</h1>
          <p style="font-size:12px;">Our Digital Yawatmal</p>
        </a>
      </div>

      <div class="col-7 text-center align-self-center">
        <div class="input-group" style="width: 90%;margin-left:auto;">
          
          <input type="text" class="form-control" placeholder="Search for the products, Services and More in Yavatmal" aria-label="Input group example" aria-describedby="btnGroupAddon2" >
          <div class="input-group-prepend">
            <div class="input-group-text" id="btnGroupAddon2"><i class='bx bx-search'></i></div>
          </div>
        </div>
      </div>

      <div class="col-3 align-self-center">
        
        <div class="row">
          <div class="col-4 text-center align-self-center">
            <p>Sign In</p>
          </div>
          <div class="col-4 text-center align-self-center">
            <p><i class='bx bx-cart' style="font-size:20px;"></i>Cart</p>
          </div>
          <div class="col-4 text-center align-self-center">
            <p>Orders/Return</p>
          </div>
        </div>
        
      </div>
    

    </div>
    
    <div class="row headBottomBar align-items-center">
      <div class="col-2 text-center">
        <p>All Service & Products</p>
      </div>
      <div class="col-1 text-center">
        <p>MainCategories</p>
      </div>
      <div class="col-2 text-center">
        <p>Top SubCategories</p>
      </div>
      <div class="col-1 text-center">
        <p>Top Deals</p>
      </div>
      <div class="col-1 text-center">
        <p>News & Events</p>
      </div>
      <div class="col-2 text-center">
        <p>Offers & Essentials</p>
      </div>
      <div class="col-1 text-center">
        <p>Best Discounts</p>
      </div>
      <div class="col-1 text-center">
        <p>Packages</p>
      </div>
      <div class="col-1 text-center">
        <p>Customization</p>
      </div>

    </div>

  </div>
</header><?php /**PATH C:\xampp\htdocs\yavatmalkar\resources\views/auth/authLayout/navbar.blade.php ENDPATH**/ ?>