

  <footer id="footer">  
    <div class="container">
    
      <div class="copyright">
        <p>
          <a href="/">Home | </a>
          <a href="about"> About | </a>
          <a href="service"> Services | </a>
          <a href="blog"> Blog | </a>
          <a href="contact"> Contact </a>

        </p>
        &copy; Copyright <strong><span>We The People</span></strong>. All Rights Reserved
      </div>
      <div class="credits">
        Designed by <a href="https://bootstrapmade.com/">ICEICO Technolgies Pvt Ltd</a>
      </div>
    </div>
  </footer><?php /**PATH C:\xampp\htdocs\yavatmalkar\resources\views/auth/authLayout/footer.blade.php ENDPATH**/ ?>