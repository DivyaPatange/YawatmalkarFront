<section class="container-fluid" style="background:#313131;color:#fff;">
    <div class="container text-left">    
        <div class="row">
            <div class="col-md-8">
                <h3 style="color:#B3D9F5; text-align:left;">Our All Main Categories</h3>
                <div class="row pt-5">
                    <div class="col-6">
                        <p>Doctors and Medicine</p>
                        <p>Legal Services</p>
                        <p>Hospitality and Security</p>
                        <p>Beauty</p>
                        <p>Daily Needs</p>
                        <p>Home and Home Decors</p>
                        <p>Car Services</p>
                        <p>Function and Events</p>
                        <p>Tours and Travels</p>
                        <p>Electrical and Consumables</p>
                        <p>Electronics and Consumables</p>
                    </div>

                    <div class="col-6">
                        <p>Kitchen and Appliances</p>
                        <p>Gym and Fitness</p>
                        <p>Academics and Books</p>
                        <p>Banking and Finance</p>
                        <p>Garden and Agriculture</p>
                        <p>Food Snacks and Hotels</p>
                        <p>Entertainment and Theatre</p>
                        <p>Fashion and Style</p>
                        <p>Computer and Srvices</p>
                        <p>Advertising and Fles</p>
                        <p>Real Estates and Rents</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <h3 style="color:#B3D9F5; text-align:left;">CONTACT US</h3>

                <p class="pt-5">WhatsApp us</p>
                <p>7249811665</p>
                <br>
                <br>
                <p>Call Us</p>
                <p>7249811665</p>
            </div>
        </div>
    </div>
</section>