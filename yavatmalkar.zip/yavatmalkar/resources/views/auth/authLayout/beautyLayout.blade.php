<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>@yield('title') - Index</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  @include('auth.authLayout.link')
  @yield('customcss')
  
</head>

<body>
    
    <header id="header" style="background:#fff;">
        <div class="container d-flex">

        <div class="logo mr-auto">
            <h1 style="color:#232F3E;font-size:38px;font-weight:bold;">YAVATMALKAR</h1>
        </div>

        <nav class="nav-menu d-none d-lg-block">
            <ul>
            <li><a href="index.html">Home</a></li>
            <li><a href="about.html">Services</a></li>
            <li><a href="team.html">Process</a></li>
            <li><a href="team.html">Shops</a></li>
            <li><a href="contact.html">Offers</a></li>
            <li><a href="contact.html">Advertisements</a></li>
            </ul>
        </nav><!-- .nav-menu -->

        </div>
    </header>
  
    
    
  @yield('content')

  @include('auth.authLayout.beautyFooter')

  <a href="#" class="back-to-top"><i class="icofont-simple-up"></i></a>

  @include('auth.authLayout.script')
  @yield('customjs')
</body>

</html>